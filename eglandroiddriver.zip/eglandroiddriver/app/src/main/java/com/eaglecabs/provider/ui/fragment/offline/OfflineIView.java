package com.eaglecabs.provider.ui.fragment.offline;

import com.eaglecabs.provider.base.MvpView;

public interface OfflineIView extends MvpView {
    void onSuccess(Object object);
}
