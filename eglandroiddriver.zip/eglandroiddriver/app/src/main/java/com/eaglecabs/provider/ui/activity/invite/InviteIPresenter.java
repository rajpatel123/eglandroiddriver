package com.eaglecabs.provider.ui.activity.invite;

import com.eaglecabs.provider.base.MvpPresenter;

public interface InviteIPresenter<V extends InviteIView> extends MvpPresenter<V> {
}
