package com.eaglecabs.provider.ui.activity.your_trips;

import com.eaglecabs.provider.base.MvpPresenter;

public interface YourTripIPresenter<V extends YourTripIView> extends MvpPresenter<V> {
}
