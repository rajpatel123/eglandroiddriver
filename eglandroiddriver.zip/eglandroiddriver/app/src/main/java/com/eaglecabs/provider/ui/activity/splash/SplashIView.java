package com.eaglecabs.provider.ui.activity.splash;

import com.eaglecabs.provider.base.MvpView;

public interface SplashIView extends MvpView {
    void redirectHome();
}
