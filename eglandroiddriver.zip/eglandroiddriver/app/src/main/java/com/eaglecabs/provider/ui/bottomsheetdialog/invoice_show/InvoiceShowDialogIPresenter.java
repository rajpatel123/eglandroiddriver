package com.eaglecabs.provider.ui.bottomsheetdialog.invoice_show;

public interface InvoiceShowDialogIPresenter {
}
