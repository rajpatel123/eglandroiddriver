package com.eaglecabs.provider.ui.activity.invite;

import com.eaglecabs.provider.base.BasePresenter;

public class InvitePresenter<V extends InviteIView> extends BasePresenter<V> implements InviteIPresenter<V> {
}
