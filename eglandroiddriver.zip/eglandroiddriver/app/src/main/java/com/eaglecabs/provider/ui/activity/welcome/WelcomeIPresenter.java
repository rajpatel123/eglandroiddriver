package com.eaglecabs.provider.ui.activity.welcome;

import com.eaglecabs.provider.base.MvpPresenter;

public interface WelcomeIPresenter<V extends WelcomeIView> extends MvpPresenter<V> {
}
