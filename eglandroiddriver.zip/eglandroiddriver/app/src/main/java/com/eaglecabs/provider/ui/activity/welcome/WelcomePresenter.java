package com.eaglecabs.provider.ui.activity.welcome;

import com.eaglecabs.provider.base.BasePresenter;

public class WelcomePresenter<V extends WelcomeIView> extends BasePresenter<V> implements WelcomeIPresenter<V>  {


}
