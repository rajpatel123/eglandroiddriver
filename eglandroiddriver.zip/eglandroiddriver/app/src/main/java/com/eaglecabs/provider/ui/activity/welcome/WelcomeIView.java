package com.eaglecabs.provider.ui.activity.welcome;

import com.eaglecabs.provider.base.MvpView;

public interface WelcomeIView extends MvpView{
}
