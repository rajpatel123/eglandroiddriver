package com.eaglecabs.provider.ui.activity.your_trips;

import com.eaglecabs.provider.base.BasePresenter;

public class YourTripPresenter<V extends YourTripIView> extends BasePresenter<V> implements YourTripIPresenter<V> {
}
