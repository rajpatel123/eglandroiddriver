package com.eaglecabs.provider.ui.activity.your_trips;

import com.eaglecabs.provider.base.MvpView;

public interface YourTripIView extends MvpView {
}
