package com.eaglecabs.provider.ui.activity.invite;

import com.eaglecabs.provider.base.MvpView;

public interface InviteIView extends MvpView {
}
