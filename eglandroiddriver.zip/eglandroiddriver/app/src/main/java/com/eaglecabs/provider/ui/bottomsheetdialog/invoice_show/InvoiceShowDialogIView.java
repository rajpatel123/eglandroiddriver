package com.eaglecabs.provider.ui.bottomsheetdialog.invoice_show;

import com.eaglecabs.provider.base.MvpView;

public interface InvoiceShowDialogIView extends MvpView {
}
